import React, { Component } from 'react';
import logo from './logo.svg';
import evolveu from './EvolveU.jpeg';
import Questions from './components/questions/questions';
import './App.css';
let questionsxxx = [
  'q1',
  'q2 asdf asdf asdf sdaf sdaf asfd asf asf sdaf dsafsd af saef sdf asdfgfdsgfdsg dfg dfg dfg dfag sadf sdf dfg f zsdf dfgdgdsagf sdzgdfg',
  'q3',
  'q4',
  'q5',
  'q6',
// eslint-disable-next-line
  'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod \
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, \
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo \
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse \
cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non \
proident, sunt in culpa qui officia deserunt mollit anim id est laborum. ',

];

class App extends Component {

  constructor() {
    super();
    this.state = {
      questions: []
    }
  }


  componentDidMount = () => {
    fetch('http://localhost:5000/questions')
      .then(response => response.json())
      .then(data=> {
        console.log(data)
        this.setState({questions: data})
      })
  }

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <img src={evolveu} style={{height: "40px"}} className="App-logo-evolveu" alt="logo" />
          <h1 className="App-title">Welcome to EvolveuU Evaluation Criteria.</h1>
        </header>
          <p className="App-intro">
            Each week, fill out the evaluation criteria.
          </p>
          <Questions questions={this.state.questions}/>
      </div>
    );
  }
}

export default App;
